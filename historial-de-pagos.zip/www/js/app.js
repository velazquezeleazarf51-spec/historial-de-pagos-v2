const $ = s => document.querySelector(s);
const toC = n => Math.round(Number(n) * 100);
const fromC = c => c / 100;
const sumDebt = list => fromC(list.reduce((t, x) => t + toC(x.debt), 0));

/* ========== STATE ========== */
let user = null;
let cards = [];
let chat = [];
let view = 'cards';
let pending = null;
let histId = null;
let animIdx = -1;
let typing = false;
let shown = 0;
let totalFrame = null;
let photoData = null;

/* ========== STORAGE ========== */
function loadUser() {
  try {
    const raw = localStorage.getItem('mt_user');
    if (raw) {
      const parsed = JSON.parse(raw);
      user = parsed && typeof parsed.name === 'string' && parsed.name.trim()
        ? { name: parsed.name.trim().slice(0, 40), photo: typeof parsed.photo === 'string' && /^data:image\/(png|jpeg|webp|gif);base64,/i.test(parsed.photo) ? parsed.photo : null }
        : null;
    }
  } catch (e) { user = null; }
}
function saveUser() {
  try {
    localStorage.setItem('mt_user', JSON.stringify(user));
    return true;
  } catch (e) {
    alert('No se pudo guardar el perfil. Es posible que el almacenamiento esté lleno.');
    return false;
  }
}
function validCard(c) {
  return !!c && typeof c === 'object' && Number.isFinite(Number(c.id)) &&
    typeof c.name === 'string' && c.name.trim().length > 0 && c.name.length <= 80 &&
    typeof c.type === 'string' && ['CRÉDITO', 'PRÉSTAMO'].includes(c.type) &&
    Number.isFinite(Number(c.debt)) && Number(c.debt) >= 0 &&
    (c.color === '' || c.color == null || /^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/i.test(c.color)) &&
    Array.isArray(c.h) && c.h.every(x => x && typeof x === 'object' &&
      ['init', 'pago', 'cargo', 'edit'].includes(x.ty) &&
      typeof x.d === 'string' && Number.isFinite(Date.parse(x.d)) &&
      Number.isFinite(Number(x.a)) && Number(x.a) >= 0 &&
      Number.isFinite(Number(x.b)) && Number(x.b) >= 0 &&
      (x.p == null || (Number.isFinite(Number(x.p)) && Number(x.p) >= 0)) &&
      (x.x == null || (Number.isFinite(Number(x.x)) && Number(x.x) >= 0)) &&
      (x.pn == null || typeof x.pn === 'string'));
}
function loadCards() {
  try {
    const raw = localStorage.getItem('tarjetas') || '[]';
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || !parsed.every(validCard)) throw new Error('Datos de tarjetas no válidos');
    const ids = parsed.map(c => Number(c.id));
    if (new Set(ids).size !== ids.length) throw new Error('Identificadores duplicados');
    cards = parsed.map(c => ({ ...c, id: Number(c.id), debt: Number(c.debt), h: c.h.map(x => ({ ...x, a: Number(x.a), b: Number(x.b) })) }));
  } catch (e) {
    cards = [];
    alert('No se pudieron cargar las tarjetas porque los datos guardados están dañados o tienen un formato incompatible. Importa un respaldo válido.');
  }
}
function saveCards() {
  try {
    localStorage.setItem('tarjetas', JSON.stringify(cards));
    return true;
  } catch (e) {
    alert('No se pudieron guardar los cambios. El almacenamiento puede estar lleno o bloqueado.');
    return false;
  }
}

/* ========== HELPERS ========== */
const money = n => '$' + Number(n).toLocaleString('es-MX', {
  minimumFractionDigits: Number.isInteger(Number(n)) ? 0 : 2,
  maximumFractionDigits: 2
});
const esc = s => String(s).replace(/[&<>"']/g, c => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));
const norm = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

const BR = [
  ['elektra', '#0033a0,#1e63d6'], ['banco azteca', '#00a651,#006b34'], ['azteca', '#00a651,#006b34'],
  ['italika', '#d71920,#8f0f14'], ['mercado pago', '#009ee3,#0068b3'], ['mercado libre', '#ffe600,#f5c800'],
  ['amazon', '#232f3e,#ff9900'], ['walmart', '#0071ce,#004c91'], ['aurrera', '#00833e,#005a2a'],
  ['soriana', '#e30613,#9b0010'], ['chedraui', '#f58220,#c25a00'], ['costco', '#e31837,#005daa'],
  ['home depot', '#f96302,#c24e00'], ['palacio', '#111,#555'], ['sears', '#0a2d6e,#1a5fc4'],
  ['sanborns', '#c8102e,#8b0b20'], ['oxxo', '#e4002b,#ffcc00'], ['spin', '#e4002b,#ffcc00'],
  ['rappi', '#ff441f,#ff7a59'], ['didi', '#ff7a00,#ffb066'], ['klar', '#111,#3a3a3a'],
  ['inbursa', '#00549f,#003366'], ['scotia', '#ec111a,#a30d13'], ['afirme', '#00843d,#005c2a'],
  ['banregio', '#f26522,#b84410'], ['visa', '#1a1f71,#3b5bdb'], ['master', '#eb001b,#f79e1b'],
  ['amex', '#006fcf,#00a3e0'], ['american', '#006fcf,#00a3e0'], ['bbva', '#072146,#1464a5'],
  ['santander', '#cc0000,#ff5a5a'], ['nu', '#820ad1,#b44cf0'], ['banorte', '#eb0029,#b3001f'],
  ['hsbc', '#db0011,#333'], ['citi', '#056dae,#0a2f5c'], ['banamex', '#0a4d8c,#e4002b'],
  ['liverpool', '#e10098,#7a0a5e'], ['coppel', '#ffd100,#e6a800'], ['oro', '#c9a227,#7a5c00']
];
function grad(n) {
  n = norm(n);
  for (const [k, g] of BR) if (n.includes(k)) return g;
  let h = 0;
  for (const c of n) h = (h * 31 + c.charCodeAt(0)) % 360;
  return `hsl(${h},58%,42%),hsl(${(h + 38) % 360},62%,55%)`;
}

function find(t) {
  const n = norm(String(t || ''));
  return [...cards]
    .filter(c => c && typeof c.name === 'string')
    .sort((a, b) => b.name.length - a.name.length)
    .find(c => {
      const name = norm(c.name).trim();
      if (!name) return false;
      const re = new RegExp('(^|[^a-z0-9])' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '($|[^a-z0-9])', 'i');
      return re.test(n);
    });
}

/* ========== CARD OPERATIONS ========== */
function addCard(name, debt, type, color) {
  const amount = fromC(toC(debt));
  if (!name || !name.trim() || !Number.isFinite(amount) || amount < 0) {
    alert('Escribe un nombre y una deuda válida de $0 o más.');
    return false;
  }
  if (cards.some(c => norm(c.name) === norm(name.trim()))) {
    if (!confirm('Ya existe una tarjeta con ese nombre. ¿Agregar de todas formas?')) return false;
  }
  const c = {
    id: Date.now() + Math.random(),
    name: name.trim().slice(0, 80),
    type: type === 'PRÉSTAMO' ? 'PRÉSTAMO' : 'CRÉDITO',
    color: /^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/i.test(color || '') ? color : '',
    debt: amount,
    h: []
  };
  while (cards.some(x => Number(x.id) === c.id)) c.id++;
  c.h.push({ d: new Date().toISOString(), ty: 'init', a: c.debt, b: c.debt });
  cards.push(c);
  if (!saveCards()) { cards.pop(); return false; }
  return true;
}

function move(c, ty, a) {
  if (!c || !['pago', 'cargo'].includes(ty) || !Number.isFinite(a) || a <= 0) return false;
  const previousDebt = c.debt;
  const previousHistoryLength = c.h.length;
  const debtC = toC(c.debt), aC = toC(a);
  if (aC <= 0) return false;
  const appliedC = ty === 'pago' ? Math.min(aC, debtC) : aC;
  const nextC = ty === 'pago' ? debtC - appliedC : debtC + appliedC;
  if (!Number.isFinite(nextC)) return false;
  const applied = fromC(appliedC);
  const excess = ty === 'pago' ? fromC(aC - appliedC) : 0;
  c.debt = fromC(nextC);
  const entry = { d: new Date().toISOString(), ty, a: applied, b: c.debt };
  if (excess > 0) entry.x = excess;
  c.h.push(entry);
  if (!saveCards()) {
    c.debt = previousDebt;
    c.h.length = previousHistoryLength;
    return false;
  }
  return applied;
}

function doMove(c, ty, a) {
  if (!Number.isFinite(a) || a <= 0) return 'Escribe un monto mayor que $0.';
  if (ty === 'pago' && c.debt <= 0) return `${c.name} ya está pagada ✅`;
  const previous = c.debt;
  const applied = move(c, ty, a);
  if (applied === false) return 'No se pudo registrar el movimiento.';
  if (ty === 'pago' && toC(a) > toC(previous)) {
    return `Pago de ${money(a)} recibido en ${c.name}; se aplicaron ${money(applied)} para liquidar y quedó registrado un excedente de ${money(fromC(toC(a) - toC(previous)))}. Saldo: $0. ✅`;
  }
  return ty === 'pago'
    ? `Pago de ${money(applied)} registrado en ${c.name}. Ahora debes ${money(c.debt)}. ✅`
    : `Gasto de ${money(applied)} sumado a ${c.name}. Ahora debes ${money(c.debt)}.`;
}

/* ========== ASSISTANT ========== */
function reply(t) {
  const n = norm(t);
  const m = t.replace(/,/g, '').match(/\d+(\.\d+)?/);
  let amt = m ? +m[0] : null;
  let c = find(t);

  if (pending && pending.ty && c &&
      !/\b(pag|abon|rest|desc|quit|deposit|liquid|baj|gast|compr|carg|sum|agreg|anad|aument|sub)\b/.test(n) &&
      !/^\s*[+-]\s*\$?\s*\d/.test(t.trim())) {
    amt = null;
  }

  if (/cancel/.test(n) && pending) {
    pending = null;
    return 'Listo, cancelado.';
  }

  if (pending && pending.card) {
    const cc = c || pending.card;
    if (amt) {
      pending = null;
      return doMove(cc, 'pago', amt);
    }
    if (/todo|total|complet|liquid/.test(n)) {
      pending = null;
      return doMove(cc, 'pago', cc.debt);
    }
  }

  if (/\b(hola|buenas|hey)\b/.test(n)) {
    return `¡Hola${user ? ' ' + user.name.split(' ')[0] : ''}! ¿En qué puedo ayudarte hoy?`;
  }
  if (/gracias/.test(n)) return '¡Con gusto!';
  if (/ayuda|comando|que puedes/.test(n)) {
    return 'COMANDOS\n\n➖ Pagos:\n• pagué 500 a BBVA\n• abono 300 Nu\n• -500 BBVA\n\n📊 Consultar:\n• cuánto debo\n• historial de Nu\n\nTambién puedes tocar una tarjeta y elegir Pagar o Historial.';
  }
  if (/historial|movimientos/.test(n)) {
    view = 'hist';
    histId = c ? c.id : null;
    render();
    return c ? `Aquí está el historial de ${c.name}.` : 'Aquí está tu historial completo.';
  }

  const sg = t.trim().match(/^([+-])\s*\$?\s*\d/);
  const ty = /\b(pag|abon|rest|desc|quit|deposit|liquid|baj)/.test(n) ? 'pago'
           : /\b(gast|compr|carg|sum|agreg|anad|aument|sub)/.test(n) ? 'cargo'
           : sg ? (sg[1] === '-' ? 'pago' : 'cargo') : null;

  if (ty === 'pago' && !amt && c) {
    if (c.debt <= 0) return `${c.name} ya está pagada ✅`;
    pending = { card: c };
    return `¿Cuánto pagaste a ${c.name}? Hoy debes ${money(c.debt)}.`;
  }

  if (ty && amt) {
    if (!cards.length) return 'Aún no tienes tarjetas. Agrégala en la pestaña Tarjetas.';
    if (!c && cards.length === 1) c = cards[0];
    if (!c) {
      pending = { ty, a: amt };
      return `¿A cuál tarjeta? ${cards.map(x => x.name).join(', ')}`;
    }
    return doMove(c, ty, amt);
  }

  if (pending && pending.ty && c && !amt) {
    const p = pending;
    pending = null;
    return doMove(c, p.ty, p.a);
  }

  if (/cuanto debo|deuda|saldo|total|debo/.test(n)) {
    if (c) return `En ${c.name} debes ${money(c.debt)}.`;
    if (!cards.length) return 'No tienes tarjetas registradas todavía.';
    return cards.map(x => `• ${x.name}: ${money(x.debt)}`).join('\n') +
           `\n\nTotal: ${money(sumDebt(cards))}`;
  }

  if (/tarjetas/.test(n)) {
    view = 'cards';
    render();
    return 'Estas son tus tarjetas.';
  }

  return 'No te entendí bien 🤔. Toca una tarjeta o escribe "ayuda".';
}

const responseQueue = [];
function ask(t) {
  chat.push({ t, me: true });
  responseQueue.push(t);
  render();
  processResponseQueue();
}
function processResponseQueue() {
  if (typing || !responseQueue.length) return;
  typing = true;
  render();
  const message = responseQueue.shift();
  setTimeout(() => {
    const r = reply(message);
    chat.push({ t: r });
    typing = false;
    render();
    processResponseQueue();
  }, 600);
}

/* ========== RENDER ========== */
function animTot(to) {
  const el = $('#tot');
  if (totalFrame !== null) cancelAnimationFrame(totalFrame);
  const from = shown;
  const t0 = performance.now();
  const changed = Math.abs(to - from) > 0.5;
  shown = to;
  if (changed) {
    el.classList.remove('pop');
    void el.offsetWidth;
    el.classList.add('pop');
  }
  function frame(t) {
    const p = Math.min(1, (t - t0) / 550);
    const e = 1 - Math.pow(1 - p, 3);
    el.textContent = money(p < 1 ? from + (to - from) * e : to);
    if (p < 1) totalFrame = requestAnimationFrame(frame);
    else totalFrame = null;
  }
  totalFrame = requestAnimationFrame(frame);
}

function cardHTML(c, i, open) {
  const safeColor = /^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/i.test(c.color || '') ? c.color : '';
  const bg = safeColor
    ? `linear-gradient(135deg,${safeColor},color-mix(in srgb,${safeColor} 60%,#fff))`
    : `linear-gradient(135deg,${grad(c.name)})`;
  const darkText = /coppel|mercado libre/.test(norm(c.name)) ? ';color:#1a1a1a' : '';
  return `<div class="card" ${open ? `data-open="${Number(c.id)}"` : ''} style="animation-delay:${i * 70}ms;background:${bg}${darkText}">
    <div class="top"><div class="chipimg"></div><span>${esc(c.type || 'CRÉDITO')}</span></div>
    <div>
      <div class="nm">${esc(c.name)}</div>
      <div class="lb">Deuda actual</div>
      <div class="am">${money(c.debt)}</div>
    </div>
    <span class="pill">${c.debt > 0 ? 'Ver opciones ›' : 'Pagada ✅'}</span>
  </div>`;
}

function rowsHTML(list) {
  const rows = list.flatMap(c => c.h.map(x => ({ ...x, n: c.name })))
                   .sort((a, b) => b.d.localeCompare(a.d));
  if (!rows.length) return '<div class="empty">Sin movimientos todavía.</div>';
  return rows.map((r, i) => {
    let label;
    if (r.ty === 'pago') label = '− ';
    else if (r.ty === 'cargo') label = '+ ';
    else if (r.ty === 'edit') label = 'Edición ';
    else label = 'Inicial ';
    return `<div class="row" style="animation-delay:${i * 40}ms">
      <div>${esc(r.n)}<small>${new Date(r.d).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' })}</small></div>
      <div><span class="${r.ty === 'pago' ? 'pay' : ''}">${label}${money(r.a)}</span>
      <small>${r.ty === 'edit' && r.p != null ? `Antes: ${money(r.p)} → Ahora: ${money(r.b)}` : `Deuda: ${money(r.b)}`}${r.ty === 'edit' && r.pn ? `<br>Nombre anterior: ${esc(r.pn)}` : ''}${r.x ? `<br>Excedente sin aplicar: ${money(r.x)}` : ''}</small></div>
    </div>`;
  }).join('');
}

function renderHeader() {
  const av = $('#headerAvatar');
  const nameEl = $('#headerName');
  if (user) {
    nameEl.textContent = user.name;
    if (user.photo) {
      av.innerHTML = `<img src="${user.photo}" alt="Foto">`;
    } else {
      const initials = user.name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
      av.textContent = initials || 'VS';
    }
  }
}

function render() {
  animTot(sumDebt(cards));
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.v === view));

  let h = '';
  if (view === 'cards') {
    h = '<h2>Mis deudas</h2>' +
        cards.map((c, i) => cardHTML(c, i, true)).join('') +
        `<button class="addtile" data-add="1">＋ Agregar deuda</button>
         <button class="addtile" data-export="1">⇩ Exportar respaldo</button>
         <button class="addtile" data-import="1">⇧ Importar respaldo</button>`;
  } else if (view === 'chat') {
    h = chat.map((m, i) =>
      `<div class="msg ${m.me ? 'me' : 'bot'}">${esc(m.t)}</div>`
    ).join('');
    if (typing) h += '<div class="msg bot typing"><i></i><i></i><i></i></div>';

    if (pending && pending.card) {
      const d = pending.card.debt;
      h += `<div class="chips">
        <button class="chip pay" data-q="todo">Pagar todo (${money(d)})</button>
        ${[100, 500, 1000].filter(a => a < d).map(a =>
          `<button class="chip" data-q="${a}">${money(a)}</button>`
        ).join('')}
        <button class="chip" data-q="cancelar">Cancelar</button>
      </div>`;
    } else {
      h += cards.length
        ? `<div class="chips">${cards.map(c =>
            `<button class="chip pay" data-pay="${esc(c.name)}">${c.debt > 0 ? '💳 ' + esc(c.name) + ' · ' + money(c.debt) : '✅ ' + esc(c.name)}</button>`
          ).join('')}</div>`
        : '<div class="chips"><button class="chip pay" data-add="1">➕ Agregar mi primera tarjeta</button></div>';
      h += `<div class="chips">${['Cuánto debo', 'Historial', 'Comandos'].map(x =>
        `<button class="chip" data-q="${x}">${x}</button>`
      ).join('')}</div>`;
    }
  } else {
    h = '<h2>Historial</h2><div class="chips">' +
        `<button class="chip${!histId ? ' on' : ''}" data-f="all">Todas</button>` +
        cards.map(c =>
          `<button class="chip${histId === c.id ? ' on' : ''}" data-f="${c.id}">${esc(c.name)}</button>`
        ).join('') +
        '</div>' + rowsHTML(cards.filter(c => !histId || c.id === histId));
  }

  $('#main').innerHTML = h;
  $('#main').scrollTop = view === 'chat' ? 1e9 : 0;
  $('#f').style.display = view === 'chat' ? 'flex' : 'none';
}

/* ========== SHEET / MODALS ========== */
function sheet(id) {
  const c = cards.find(x => x.id == id);
  if (!c) { closeAll(); return; }
  const l = c.h[c.h.length - 1];
  let lastTxt = '';
  if (l) {
    if (l.ty === 'pago') lastTxt = 'pago de ' + money(l.a);
    else if (l.ty === 'cargo') lastTxt = 'cargo de ' + money(l.a);
    else if (l.ty === 'edit') lastTxt = (l.p != null ? 'edición de ' + money(l.p) + ' a ' : 'edición a ') + money(l.a);
    else lastTxt = 'saldo inicial de ' + money(l.a);
  }
  $('#sh').innerHTML = `
    <div class="grab"></div>
    ${cardHTML(c, 0, false).replace('Ver opciones ›', '')}
    <p class="last">${l ? 'Último movimiento: ' + lastTxt : ''}</p>
    <div class="acts">
      ${c.debt > 0 ? `<button class="pri" data-gopay="${esc(c.name)}">Pagar</button>` : ''}
      <button class="sec" data-gohist="${c.id}">Historial</button>
      <button class="sec" data-edit="${c.id}">Editar</button>
      <button class="sec" data-delete="${c.id}">Eliminar</button>
    </div>
    <div class="wm">Velázquez Studio ©</div>`;
  $('#sh').classList.add('on');
  $('#ov').classList.add('on');
}

function closeAll() {
  $('#sh').classList.remove('on');
  $('#md').classList.remove('on');
  $('#ov').classList.remove('on');
}

/* ========== EXPORT / IMPORT ========== */
function isNative() {
  try { return !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()); }
  catch (e) { return false; }
}
function nativePlugin(name) {
  return (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins[name]) ||
         (window.Capacitor && Capacitor.registerPlugin ? Capacitor.registerPlugin(name) : null);
}
async function cleanOldBackups() {
  try {
    if (!isNative()) return;
    const FS = nativePlugin('Filesystem');
    const r = await FS.readdir({ path: '', directory: 'CACHE' });
    for (const f of (r.files || [])) {
      const n = typeof f === 'string' ? f : f.name;
      if (n && n.indexOf('respaldo-') === 0) await FS.deleteFile({ path: n, directory: 'CACHE' });
    }
  } catch (e) {}
}
async function exportData() {
  const data = {
    app: 'Historial de pagos · Velázquez Studio',
    version: 3,
    exportedAt: new Date().toISOString(),
    user,
    cards
  };
  const json = JSON.stringify(data, null, 2);
  const fname = 'respaldo-historial-pagos-' + new Date().toISOString().slice(0, 10) + '.json';
  if (isNative()) {
    try {
      await cleanOldBackups();
      const FS = nativePlugin('Filesystem'), SH = nativePlugin('Share');
      if (!FS || !SH) throw new Error('Faltan componentes de la app.');
      const w = await FS.writeFile({ path: fname, data: json, directory: 'CACHE', encoding: 'utf8' });
      await SH.share({ title: 'Respaldo Historial de pagos', url: w.uri, dialogTitle: 'Guardar o enviar respaldo' });
    } catch (e) {
      const msg = String((e && e.message) || e);
      if (/cancel/i.test(msg)) return;
      alert('No se pudo exportar el respaldo: ' + msg);
    }
    return;
  }
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fname;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function importData() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = isNative() ? '*/*' : '.json,application/json';
  input.onchange = () => {
    const file = input.files && input.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { alert('El respaldo supera el límite de 5 MB.'); return; }
    const reader = new FileReader();
    reader.onerror = () => alert('No se pudo leer el archivo seleccionado.');
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data || !Array.isArray(data.cards) || !data.cards.every(validCard)) {
          alert('El respaldo contiene tarjetas o movimientos con datos inválidos. No se modificó tu información.');
          return;
        }
        const ids = data.cards.map(c => Number(c.id));
        if (new Set(ids).size !== ids.length) { alert('El respaldo contiene identificadores duplicados.'); return; }
        let importedUser = user;
        if (data.user !== undefined && data.user !== null) {
          if (typeof data.user !== 'object' || typeof data.user.name !== 'string' || !data.user.name.trim() || data.user.name.length > 40 ||
              (data.user.photo != null && (typeof data.user.photo !== 'string' || !/^data:image\/(png|jpeg|webp|gif);base64,/i.test(data.user.photo) || data.user.photo.length > 3 * 1024 * 1024))) {
            alert('El perfil incluido en el respaldo no es válido. No se modificó tu información.');
            return;
          }
          importedUser = { name: data.user.name.trim(), photo: data.user.photo || null };
        }
        if (!confirm(`Se importarán ${data.cards.length} tarjetas${data.user ? ' y el perfil de ' + data.user.name : ''}. Esta acción reemplazará tus tarjetas actuales. ¿Continuar?`)) return;
        const oldCards = cards, oldUser = user;
        cards = data.cards.map(c => ({ ...c, id: Number(c.id), debt: Number(c.debt), h: c.h.map(x => ({ ...x, a: Number(x.a), b: Number(x.b) })) }));
        user = importedUser;
        try {
          localStorage.setItem('tarjetas', JSON.stringify(cards));
          if (data.user) localStorage.setItem('mt_user', JSON.stringify(user));
        } catch (e) {
          cards = oldCards; user = oldUser;
          try { localStorage.setItem('tarjetas', JSON.stringify(oldCards)); if (oldUser) localStorage.setItem('mt_user', JSON.stringify(oldUser)); } catch (_) {}
          alert('No hay espacio suficiente para importar. Tus datos anteriores se conservaron en memoria.');
          return;
        }
        pending = null; histId = null; view = 'cards';
        renderHeader(); render();
        alert('Respaldo importado correctamente.');
      } catch (e) { alert('No se pudo leer el respaldo. Verifica que sea un archivo JSON válido.'); }
    };
    reader.readAsText(file);
  };
  input.click();
}

/* ========== EDIT / DELETE ========== */
function editCard(id) {
  const c = cards.find(x => x.id === id);
  if (!c) return;
  const name = prompt('Nombre de la tarjeta o préstamo:', c.name);
  if (name === null) return;
  if (!name.trim()) { alert('El nombre no puede estar vacío.'); return; }
  const raw = prompt('Deuda actual (solo número):', String(c.debt));
  if (raw === null) return;
  const amountRaw = Number(String(raw).replace(/,/g, '').trim());
  if (raw.trim() === '' || !Number.isFinite(amountRaw) || amountRaw < 0) {
    alert('Introduce una deuda válida de $0 o más.');
    return;
  }
  const amount = fromC(toC(amountRaw));
  const oldName = c.name, oldDebt = c.debt, oldLength = c.h.length;
  c.name = name.trim().slice(0, 80);
  c.debt = amount;
  const editEntry = { d: new Date().toISOString(), ty: 'edit', a: amount, b: amount, p: oldDebt };
  if (c.name !== oldName) editEntry.pn = oldName;
  c.h.push(editEntry);
  if (!saveCards()) {
    c.name = oldName; c.debt = oldDebt; c.h.length = oldLength;
    return;
  }
  closeAll();
  render();
}

function deleteCard(id) {
  const c = cards.find(x => x.id === id);
  if (!c) return;
  if (!confirm(`¿Eliminar "${c.name}" y todo su historial?`)) return;
  const previous = cards;
  cards = cards.filter(x => x.id !== id);
  if (!saveCards()) { cards = previous; return; }
  if (histId === id) histId = null;
  closeAll();
  render();
}

/* ========== ADD CARD MODAL ========== */
let M = { s: 1, type: 'CRÉDITO', name: '', color: '' };
const LIST = {
  'CRÉDITO': ['Coppel', 'Elektra', 'Liverpool', 'Walmart', 'Mercado Pago', 'Amazon', 'BBVA', 'Santander', 'Banorte', 'Nu', 'Citibanamex', 'HSBC', 'Visa', 'Mastercard', 'American Express', 'Klar'],
  'PRÉSTAMO': ['Banco Azteca', 'Elektra', 'Coppel', 'Italika', 'Mercado Pago', 'Inbursa', 'Afirme', 'Banregio', 'Klar', 'Rappi']
};
const COLORS = ['#4f46e5', '#7c3aed', '#e11d48', '#059669', '#ea580c', '#0284c7', '#18181b', '#ca8a04', '#db2777', '#1e3a8a'];

function modal() {
  M = { s: 1, type: 'CRÉDITO', name: '', color: '' };
  mrender();
  $('#md').classList.add('on');
  $('#ov').classList.add('on');
}

function mrender() {
  let h = '';
  if (M.s === 1) {
    h = `<h2>¿Qué quieres agregar?</h2>
      <button class="opt" data-mt="CRÉDITO"><b>💳 Tarjeta</b><small>Crédito de tienda o banco</small></button>
      <button class="opt" data-mt="PRÉSTAMO"><b>🤝 Préstamo</b><small>De una empresa, banco o persona</small></button>
      <div class="acts"><button class="sec" data-mx="1">Cancelar</button></div>`;
  } else if (M.s === 2) {
    h = `<h2>${M.type === 'PRÉSTAMO' ? '¿De qué empresa?' : '¿Qué tarjeta es?'}</h2>
      <div class="brands">
        ${LIST[M.type].map(n =>
          `<button class="chip" data-mb="${n}"><i style="background:linear-gradient(135deg,${grad(n)})"></i>${n}</button>`
        ).join('')}
        <button class="chip pay" data-mo="1">＋ Otra</button>
      </div>
      <div class="acts"><button class="sec" data-mback="1">Atrás</button></div>`;
  } else if (M.s === 3) {
    h = `<h2>${M.type === 'PRÉSTAMO' ? 'Nuevo préstamo' : 'Nueva tarjeta'}</h2>
      <label>Nombre</label>
      <input id="cn" placeholder="${M.type === 'PRÉSTAMO' ? 'Ej: Préstamo de Juan' : 'Ej: Tarjeta de mi tienda'}" value="${esc(M.name)}">
      <label>Color de la tarjeta</label>
      <div class="sw">
        ${COLORS.map(c =>
          `<button class="swb${M.color === c ? ' on' : ''}" data-mc="${c}" style="background:linear-gradient(135deg,${c},color-mix(in srgb,${c} 60%,#fff))"></button>`
        ).join('')}
      </div>
      <div class="acts">
        <button class="sec" data-mback="1">Atrás</button>
        <button class="pri" data-mnext="1">Continuar</button>
      </div>`;
  } else {
    h = `<h2>¿Cuánto debes?</h2>
      <div class="chosen">
        <i style="background:${M.color ? M.color : 'linear-gradient(135deg,' + grad(M.name) + ')'}"></i>
        <b>${esc(M.name)}</b>
        <span>${M.type}</span>
      </div>
      <label>Monto de deuda</label>
      <input id="ca" inputmode="decimal" placeholder="0.00" autocomplete="off">
      <div class="acts">
        <button class="sec" data-mback="1">Atrás</button>
        <button class="pri" data-msave="1">Guardar</button>
      </div>`;
  }
  $('#md').innerHTML = h;
  const ca = $('#ca');
  if (ca) {
    liveFmt(ca, true);
    ca.focus();
  }
  const cn = $('#cn');
  if (cn) cn.focus();
}

function fmtNum(s) {
  return s.replace(/\d[\d,]*(?:\.\d*)?/g, m => {
    const p = m.replace(/,/g, '').split('.');
    return p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (p.length > 1 ? '.' + p[1] : '');
  });
}
function liveFmt(el, strict) {
  const clean = s => strict ? s.replace(/[^\d.,]/g, '') : s;
  el.addEventListener('input', function () {
    const k = clean(el.value.slice(0, el.selectionStart)).replace(/,/g, '').length;
    const v = fmtNum(clean(el.value));
    if (v === el.value) return;
    el.value = v;
    let c = 0, i = 0;
    for (; i < v.length && c < k; i++) if (v[i] !== ',') c++;
    try { el.setSelectionRange(i, i); } catch (e) {}
  });
}

/* ========== PROFILE ========== */
function editProfile() {
  photoData = user && user.photo ? user.photo : null;
  const previewHtml = photoData
    ? `<img src="${photoData}" alt="Foto">`
    : '<span>📷</span>';
  const initials = user && user.name
    ? user.name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase()
    : 'VS';
  $('#md').innerHTML = `
    <h2>Editar perfil</h2>
    <p class="sub">Actualiza tu nombre o foto de perfil.</p>
    <div class="profile-photo-edit photo-wrap" id="profilePhotoWrap" title="Cambiar foto">
      <div class="photo-circle" id="profilePhotoPreview">${previewHtml}</div>
      <div class="photo-badge">＋</div>
    </div>
    <label for="profileName">Tu nombre</label>
    <input type="text" id="profileName" value="${esc(user ? user.name : '')}" maxlength="40" autocomplete="name">
    <label>Bloqueo con PIN ${getPin() ? '(activado)' : '(opcional)'}</label>
    <input type="password" id="pinNew" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="${getPin() ? 'Nuevo PIN (4 a 6 números)' : 'PIN de 4 a 6 números'}" autocomplete="off">
    <input type="password" id="pinNew2" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="Repite el PIN" autocomplete="off" style="margin-top:8px">
    <div class="acts" style="margin-top:10px">
      <button class="sec" data-pinsave="1">${getPin() ? 'Cambiar PIN' : 'Activar PIN'}</button>
      ${getPin() ? '<button class="sec" data-pinoff="1">Quitar PIN</button>' : ''}
    </div>
    <div class="acts">
      <button class="sec" data-pcancel="1">Cancelar</button>
      <button class="pri-act" data-psave="1">Guardar</button>
    </div>`;
  $('#md').classList.add('on');
  $('#ov').classList.add('on');
  const nameInput = $('#profileName');
  if (nameInput) nameInput.focus();

  $('#profilePhotoWrap').onclick = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = () => {
      const file = input.files[0];
      if (!file) return;
      if (file.size > 2 * 1024 * 1024) {
        alert('La imagen es muy grande (máx. 2 MB).');
        return;
      }
      const reader = new FileReader();
      reader.onerror = () => alert('No se pudo cargar la imagen.');
      reader.onload = () => {
        if (typeof reader.result !== 'string' || !/^data:image\/(png|jpeg|webp|gif);base64,/i.test(reader.result)) {
          alert('Usa una imagen PNG, JPG, WEBP o GIF.');
          return;
        }
        photoData = reader.result;
        $('#profilePhotoPreview').innerHTML = `<img src="${photoData}" alt="Foto">`;
      };
      reader.readAsDataURL(file);
    };
    input.click();
  };
}

function saveProfileFromModal() {
  const name = ($('#profileName') || {}).value;
  if (!name || !name.trim()) {
    alert('El nombre no puede estar vacío.');
    return;
  }
  user = {
    name: name.trim().slice(0, 40),
    photo: photoData || (user && user.photo) || null
  };
  if (!saveUser()) return;
  closeAll();
  renderHeader();
}



/* ========== PIN ========== */
const PIN_KEY = 'mt_pin';
const PIN_GRACE_MS = 30000;
let hiddenAt = 0;
function getPin() {
  try {
    const p = JSON.parse(localStorage.getItem(PIN_KEY) || 'null');
    return p && typeof p.s === 'string' && typeof p.h === 'string' ? p : null;
  } catch (e) { return null; }
}
function pinSupported() { return !!(window.crypto && crypto.subtle && window.TextEncoder); }
const toHex = u8 => Array.from(u8).map(b => b.toString(16).padStart(2, '0')).join('');
const fromHex = h => new Uint8Array((h.match(/../g) || []).map(x => parseInt(x, 16)));
async function pinHash(pin, saltHex) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: fromHex(saltHex), iterations: 150000, hash: 'SHA-256' }, key, 256);
  return toHex(new Uint8Array(bits));
}
async function savePin(pin) {
  const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
  const h = await pinHash(pin, salt);
  localStorage.setItem(PIN_KEY, JSON.stringify({ s: salt, h }));
}
let lockTimer = null;
function lockUntil() { return Number(localStorage.getItem('mt_pin_until') || 0); }
function showLock() {
  if (!getPin()) return;
  const el = $('#lock');
  el.classList.add('on');
  $('#lockMsg').textContent = '';
  $('#lockIn').value = '';
  closeAll();
  setTimeout(() => $('#lockIn').focus(), 50);
}
function hideLock() {
  $('#lock').classList.remove('on');
  $('#lockIn').value = '';
  $('#lockMsg').textContent = '';
}
async function tryUnlock() {
  const p = getPin();
  if (!p) { hideLock(); return; }
  const wait = lockUntil() - Date.now();
  if (wait > 0) { $('#lockMsg').textContent = 'Demasiados intentos. Espera ' + Math.ceil(wait / 1000) + ' s.'; return; }
  const v = $('#lockIn').value.trim();
  if (!/^\d{4,6}$/.test(v)) { $('#lockMsg').textContent = 'Escribe tu PIN de 4 a 6 dígitos.'; return; }
  let ok = false;
  try { ok = (await pinHash(v, p.s)) === p.h; } catch (e) {}
  if (ok) {
    localStorage.removeItem('mt_pin_fails');
    localStorage.removeItem('mt_pin_until');
    hideLock();
    return;
  }
  const fails = Number(localStorage.getItem('mt_pin_fails') || 0) + 1;
  localStorage.setItem('mt_pin_fails', String(fails));
  $('#lockIn').value = '';
  if (fails >= 5) {
    localStorage.setItem('mt_pin_until', String(Date.now() + 30000 * Math.min(8, fails - 4)));
    $('#lockMsg').textContent = 'PIN incorrecto. Espera unos segundos antes de reintentar.';
  } else {
    $('#lockMsg').textContent = 'PIN incorrecto (' + fails + ' de 5).';
  }
}
function forgotPin() {
  if (!confirm('Si olvidaste el PIN, la única opción es borrar TODOS los datos de la app (tarjetas, historial y perfil). ¿Continuar?')) return;
  if (!confirm('Esta acción no se puede deshacer. ¿Borrar todo?')) return;
  try { localStorage.clear(); } catch (e) {}
  location.reload();
}
async function pinSaveFromModal() {
  const a = ($('#pinNew') || {}).value || '', b = ($('#pinNew2') || {}).value || '';
  if (!pinSupported()) { alert('Este dispositivo no permite crear un PIN seguro.'); return; }
  if (!/^\d{4,6}$/.test(a)) { alert('El PIN debe tener de 4 a 6 números.'); return; }
  if (a !== b) { alert('Los dos PIN no coinciden.'); return; }
  try {
    await savePin(a);
    localStorage.removeItem('mt_pin_fails');
    localStorage.removeItem('mt_pin_until');
    alert('PIN guardado. La app se bloqueará al abrirla y tras 30 segundos fuera de ella.');
    editProfile();
  } catch (e) { alert('No se pudo guardar el PIN.'); }
}
function pinOff() {
  if (!confirm('¿Quitar el bloqueo con PIN?')) return;
  try {
    localStorage.removeItem(PIN_KEY);
    localStorage.removeItem('mt_pin_fails');
    localStorage.removeItem('mt_pin_until');
  } catch (e) {}
  editProfile();
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { hiddenAt = Date.now(); return; }
  if (getPin() && hiddenAt && Date.now() - hiddenAt > PIN_GRACE_MS) showLock();
});

/* ========== TUTORIAL ========== */
const TUTORIAL_STEPS = [
  {
    icon: '💳',
    title: 'Control de deudas',
    text: 'Aquí registras cada tarjeta o préstamo que tengas. El total de lo que debes aparece siempre arriba a la derecha.'
  },
  {
    icon: '＋',
    title: 'Agregar una deuda',
    text: 'En la pestaña Tarjetas usa «Agregar deuda». Elige el tipo, el nombre (o una marca conocida) y el saldo actual. Puedes editar o eliminar después.'
  },
  {
    icon: '💬',
    title: 'Asistente de pagos',
    text: 'En Asistente escribes en lenguaje natural, por ejemplo «pagué 500 a BBVA» o «cuánto debo». También puedes tocar una tarjeta y confirmar el monto.'
  },
  {
    icon: '◷',
    title: 'Historial',
    text: 'Cada pago, cargo o ajuste queda guardado. Filtra por tarjeta o revisa todos los movimientos en un solo listado.'
  },
  {
    icon: '👤',
    title: 'Perfil y respaldos',
    text: 'Toca tu foto o iniciales para cambiar nombre y foto. Desde Tarjetas puedes exportar o importar un respaldo JSON. Todo se guarda solo en este dispositivo.'
  }
];

let tutStep = 0;

function hasSeenTutorial() {
  try {
    return localStorage.getItem('mt_tutorial') === '1';
  } catch (e) {
    return false;
  }
}

function markTutorialDone() {
  try {
    localStorage.setItem('mt_tutorial', '1');
  } catch (e) {}
}

function showTutorial() {
  tutStep = 0;
  renderTutorialStep();
  const el = $('#tutorial');
  el.classList.add('on');
  el.setAttribute('aria-hidden', 'false');
}

function hideTutorial() {
  const el = $('#tutorial');
  el.classList.remove('on');
  el.setAttribute('aria-hidden', 'true');
  markTutorialDone();
}

function renderTutorialStep() {
  const s = TUTORIAL_STEPS[tutStep];
  if (!s) return;
  const icon = $('#tutIcon');
  icon.textContent = s.icon;
  icon.classList.remove('pulse');
  void icon.offsetWidth;
  icon.classList.add('pulse');
  $('#tutTitle').textContent = s.title;
  $('#tutText').textContent = s.text;
  document.querySelectorAll('.tut-dot').forEach((d, i) => {
    d.classList.toggle('on', i === tutStep);
  });
  const next = $('#tutNext');
  next.textContent = tutStep === TUTORIAL_STEPS.length - 1 ? 'Empezar' : 'Siguiente';
}

function nextTutorial() {
  if (tutStep >= TUTORIAL_STEPS.length - 1) {
    hideTutorial();
    return;
  }
  tutStep++;
  renderTutorialStep();
}

function showOnboarding() {
  $('#onboard').classList.add('on');
  $('#userName').focus();
}

function finishOnboarding() {
  const name = $('#userName').value.trim();
  if (!name) return;
  user = { name: name.slice(0, 40), photo: photoData || null };
  if (!saveUser()) { user = null; return; }
  $('#onboard').classList.remove('on');
  renderHeader();
  chat = [{ t: `Hola, ${name.split(' ')[0]}.\n\nCuando registres un pago, tócalo en Tarjetas o escríbelo en Asistente. Si necesitas ayuda, escribe «ayuda».` }];
  render();
  if (!hasSeenTutorial()) showTutorial();
}

/* ========== EVENTS ========== */
$('#md').onclick = e => {
  const b = e.target.closest('button');
  if (!b) return;
  const d = b.dataset;
  if (d.pcancel) { closeAll(); return; }
  if (d.psave) { saveProfileFromModal(); return; }
  if (d.pinsave) { pinSaveFromModal(); return; }
  if (d.pinoff) { pinOff(); return; }
  if (d.mt) { M.type = d.mt; M.s = 2; }
  else if (d.mb) { M.name = d.mb; M.color = ''; M.s = 4; }
  else if (d.mo) { M.name = ''; M.color = ''; M.s = 3; }
  else if (d.mc) {
    const n = $('#cn');
    if (n) M.name = n.value;
    M.color = d.mc;
  }
  else if (d.mnext) {
    const n = $('#cn').value.trim();
    if (!n) { $('#cn').focus(); return; }
    M.name = n;
    if (!M.color) M.color = COLORS[0];
    M.s = 4;
  }
  else if (d.mback) {
    M.s = M.s === 4 ? (M.color ? 3 : 2) : M.s - 1;
  }
  else if (d.msave) {
    const raw = $('#ca').value.replace(/,/g, '').trim();
    const amount = Number(raw);
    if (raw === '' || !Number.isFinite(amount) || amount < 0) {
      alert('Introduce una deuda válida de $0 o más.');
      $('#ca').focus();
      return;
    }
    if (addCard(M.name, amount, M.type, M.color)) {
      closeAll();
      view = 'cards';
      render();
    }
    return;
  }
  else if (d.mx) { closeAll(); return; }
  else return;
  mrender();
};

$('#ov').onclick = closeAll;

$('#tabs').onclick = e => {
  const b = e.target.closest('button');
  if (!b) return;
  view = b.dataset.v;
  histId = null;
  if (view !== 'chat') pending = null;
  render();
};

document.body.addEventListener('click', e => {
  const t = e.target.closest('[data-q],[data-pay],[data-add],[data-open],[data-gopay],[data-gohist],[data-f],[data-edit],[data-delete],[data-export],[data-import]');
  if (!t || t.closest('#tabs')) return;
  const d = t.dataset;
  if (d.q) ask(d.q);
  else if (d.pay) ask('Pagar a ' + d.pay);
  else if (d.add) modal();
  else if (d.open) sheet(d.open);
  else if (d.gopay) { closeAll(); view = 'chat'; ask('Pagar a ' + d.gopay); }
  else if (d.gohist) { closeAll(); view = 'hist'; histId = +d.gohist; render(); }
  else if (d.edit) editCard(+d.edit);
  else if (d.delete) deleteCard(+d.delete);
  else if (d.export) exportData();
  else if (d.import) importData();
  else if (d.f) { histId = d.f === 'all' ? null : +d.f; render(); }
});

$('#f').onsubmit = e => {
  e.preventDefault();
  const t = $('#in').value.trim();
  if (!t) return;
  $('#in').value = '';
  ask(t);
};

$('#photoWrap').onclick = () => $('#photoInput').click();
$('#photoInput').onchange = () => {
  const file = $('#photoInput').files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) {
    alert('La imagen es muy grande (máx. 2 MB).');
    return;
  }
  const reader = new FileReader();
  reader.onerror = () => alert('No se pudo cargar la imagen.');
  reader.onload = () => {
    if (typeof reader.result !== 'string' || !/^data:image\/(png|jpeg|webp|gif);base64,/i.test(reader.result)) { alert('Usa una imagen PNG, JPG, WEBP o GIF.'); return; }
    photoData = reader.result;
    $('#photoPreview').innerHTML = `<img src="${photoData}" alt="Foto">`;
  };
  reader.readAsDataURL(file);
};

$('#userName').oninput = () => {
  $('#btnStart').disabled = !$('#userName').value.trim();
};
$('#userName').onkeydown = e => {
  if (e.key === 'Enter' && !$('#btnStart').disabled) finishOnboarding();
};
$('#btnStart').onclick = finishOnboarding;
$('#profileBtn').onclick = editProfile;

liveFmt($('#in'), false);


$('#tutNext').onclick = nextTutorial;
$('#tutSkip').onclick = hideTutorial;

/* ========== INIT ========== */
loadUser();
loadCards();
cleanOldBackups();
$('#lockBtn').onclick = tryUnlock;
$('#lockIn').onkeydown = e => { if (e.key === 'Enter') tryUnlock(); };
$('#lockForgot').onclick = forgotPin;
showLock();

if (!user || !user.name) {
  showOnboarding();
} else {
  renderHeader();
  chat = [{ t: `Hola de nuevo, ${user.name.split(' ')[0]}.\n\nToca una tarjeta para registrar un pago o escribe en el asistente. «ayuda» muestra los comandos.` }];
  render();
  if (!hasSeenTutorial()) showTutorial();
}